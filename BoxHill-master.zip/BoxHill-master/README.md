Ecommerce Application 
Created an Ecommerce application in Laravel and SQL database. Customers could register themselves and view products 
from the store and add them to cart. 

![WhatsApp Image 2023-12-25 at 4 41 59 PM (1)](https://github.com/Bilal-Ahmad123/BoxHill/assets/80017963/f5cccd09-3b06-4765-86ab-13299bd75f1d)
![WhatsApp Image 2023-12-25 at 4 42 00 PM](https://github.com/Bilal-Ahmad123/BoxHill/assets/80017963/155952f4-8fee-49eb-b2c0-2361864b783a)
![WhatsApp Image 2023-12-25 at 4 42 00 PM (1)](https://github.com/Bilal-Ahmad123/BoxHill/assets/80017963/bfd97810-3db4-4f44-a754-9484e232e617)
![WhatsApp Image 2023-12-25 at 4 42 01 PM](https://github.com/Bilal-Ahmad123/BoxHill/assets/80017963/6acf8d64-ab6b-4265-aa4e-b8c5662cc23d)
![WhatsApp Image 2023-12-25 at 4 42 01 PM (1)](https://github.com/Bilal-Ahmad123/BoxHill/assets/80017963/697ea302-4130-4d9a-a29d-d6e49990d93a)
![WhatsApp Image 2023-12-25 at 4 42 01 PM (2)](https://github.com/Bilal-Ahmad123/BoxHill/assets/80017963/5e598980-58a6-41e1-a626-c9d191da6497)
![WhatsApp Image 2023-12-25 at 4 42 02 PM](https://github.com/Bilal-Ahmad123/BoxHill/assets/80017963/bc3cc58d-5826-4f59-986b-f60c9bfb51d6)
![WhatsApp Image 2023-12-25 at 4 42 02 PM (1)](https://github.com/Bilal-Ahmad123/BoxHill/assets/80017963/a0ed2492-feef-4e8d-8beb-cbbe67e4b463)
![WhatsApp Image 2023-12-25 at 4 41 59 PM](https://github.com/Bilal-Ahmad123/BoxHill/assets/80017963/cc95370b-e431-492a-a626-94cde832d92a)
