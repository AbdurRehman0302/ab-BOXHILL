<?php
 
namespace App\Http\Controllers;
 
use Illuminate\Http\Request;
 
class UserAuthentication extends Controller
{
    /**
     * Update the flight information for an existing flight.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        // $request->user()
    }
}